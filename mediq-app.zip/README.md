# 🏥 MediQ - Smart Clinic Queue & Healthcare Management System

MediQ adalah sistem manajemen antrean dan operasional klinik cerdas *production-ready* yang mengintegrasikan pendaftaran pasien mandiri (PWA), penerbitan e-tiket dengan QR Code digital, perhitungan estimasi waktu tunggu dinamis (**Dynamic ETA**), panel kendali dokter *real-time*, modul check-in resepsionis via pemindai kamera QR, dan layar **Smart TV Display** dengan sintesis panggilan suara audio Bahasa Indonesia (**Web Speech API** + Web Audio Chime).

---

## 🏗️ Struktur Folder Proyek

```
mediq/
├── package.json                   # Konfigurasi Monorepo root workspace
├── package_project.sh             # Skrip bash kompresi otomatis ke mediq-app.zip
├── .env.example                   # Contoh konfigurasi environment
├── README.md                      # Dokumentasi komprehensif sistem
│
├── server/                        # BACKEND SERVICE (Node.js + Express + Prisma)
│   ├── package.json               # Dependensi & skrip backend
│   ├── .env.example               # Template variabel environment backend
│   ├── prisma/
│   │   ├── schema.prisma          # Skema database PostgreSQL (User, Doctor, Polyclinic, Queue, Patient)
│   │   └── seed.js                # Seeding database awal (Poliklinik, Dokter, Pasien, Antrean)
│   └── src/
│       ├── controllers/
│       │   ├── auth.controller.js     # Otentikasi JWT login staff & dokter
│       │   ├── queue.controller.js    # Manajemen siklus antrean & kalkulasi
│       │   ├── doctor.controller.js   # Kontrol dokter, kuota & jadwal praktik
│       │   ├── patient.controller.js  # Booking mandiri & penerbitan e-tiket
│       │   └── clinic.controller.js   # Informasi poliklinik & overview admin
│       ├── middlewares/
│       │   ├── auth.middleware.js     # Verifikasi JWT token & proteksi RBAC
│       │   └── error.middleware.js    # Penanganan error terpusat
│       ├── routes/
│       │   ├── auth.routes.js
│       │   ├── queue.routes.js
│       │   ├── doctor.routes.js
│       │   ├── patient.routes.js
│       │   └── clinic.routes.js
│       ├── services/
│       │   ├── eta.service.js         # Algoritma perhitungan Dynamic ETA adaptif
│       │   └── queue.service.js       # Logika bisnis antrean, tiket & QR code
│       ├── sockets/
│       │   └── queue.socket.js        # Socket.io real-time synchronizer & TV broadcast
│       ├── lib/
│       │   └── prisma.js              # Prisma Client singleton
│       ├── app.js                     # Inisialisasi Express & middleware
│       └── server.js                  # Entry point HTTP & WebSocket server
│
└── client/                        # FRONTEND SERVICE (React.js + Vite + Tailwind CSS)
    ├── package.json               # Dependensi frontend & skrip build
    ├── vite.config.js             # Konfigurasi Vite & proxy dev server
    ├── tailwind.config.js         # Konfigurasi Tailwind CSS tema medis
    ├── postcss.config.js
    ├── index.html                 # HTML entry point dengan font & meta PWA
    ├── public/
    │   ├── favicon.svg            # Ikon logo medis MediQ
    │   └── manifest.json          # Manifest PWA untuk instalasi pasien mobile
    └── src/
        ├── components/
        │   ├── Navbar.jsx         # Navigasi utama dengan indikator real-time
        │   ├── Sidebar.jsx        # Navigasi panel staff & dokter
        │   ├── Badge.jsx          # Badge status dinamis (CHECKED_IN, CALLING, dll)
        │   ├── Modal.jsx          # Dialog modal interaktif
        │   └── QRScannerModal.jsx # Pemindai kamera QR scanner live (html5-qrcode)
        ├── context/
        │   ├── AuthContext.jsx    # State otentikasi sesi & hak akses peran
        │   └── SocketContext.jsx  # Koneksi WebSocket klien & event dispatcher
        ├── pages/
        │   ├── Home.jsx           # Halaman gerbang / landing page portal klinik
        │   ├── Login.jsx          # Masuk sistem untuk staf medis & dokter
        │   ├── patient/
        │   │   ├── Booking.jsx    # Pendaftaran online mandiri pasien
        │   │   ├── TicketView.jsx # Tampilan E-Tiket QR + Dynamic ETA countdown
        │   │   └── TrackQueue.jsx # Pencarian status tiket pasien
        │   ├── doctor/
        │   │   ├── DoctorDashboard.jsx # Panel panggil antrean (Panggil, Mulai, Ulang, Selesai, Lewati)
        │   │   └── DoctorSchedule.jsx  # Pengaturan kuota harian & durasi per pasien
        │   ├── admin/
        │   │   ├── AdminDashboard.jsx     # Dasbor monitoring live seluruh poliklinik
        │   │   ├── CheckInScanner.jsx     # Stasiun scanner QR check-in kedatangan
        │   │   └── WalkInRegistration.jsx # Formulir pendaftaran pasien walk-in langsung
        │   └── display/
        │       └── TvDisplay.jsx  # Layar Smart TV Display resolusi tinggi + audio TTS
        ├── services/
        │   ├── api.js             # HTTP API client terpusat
        │   └── speech.js          # Web Speech API TTS Bahasa Indonesia & Web Audio Chime
        ├── App.jsx                # Routing aplikasi & proteksi akses
        ├── main.jsx               # Render React root
        └── index.css              # Directive Tailwind & gaya cetak thermal printer
```

---

## ⚡ Teknologi & Spesifikasi (Tech Stack)

| Bagian | Teknologi | Keterangan |
| :--- | :--- | :--- |
| **Backend Runtime** | Node.js (v18+) & Express | RESTful API arsitektur modular & performa tinggi |
| **Database & ORM** | PostgreSQL & Prisma ORM | Model data relasional dengan indeks performa |
| **Real-time Sync** | Socket.io v4 | Sinkronisasi instan < 50ms antara Dokter, Pasien, & TV |
| **Dynamic ETA** | Custom Moving-Average Engine | Perhitungan waktu tunggu dinamis berdasarkan riwayat dokter hari ini |
| **Web Dashboard** | React 18, Vite, Tailwind CSS | Antarmuka responsif, modern, dan ringan |
| **Mobile Patient** | PWA-Ready (Web Manifest) | E-tiket QR digital mobile-first dapat disimpan ke layar beranda HP |
| **Smart TV Audio** | Web Speech API & Web Audio API | Sintesis suara otomatis Bahasa Indonesia + lonceng panggilan ding-dong |
| **QR Code Scanner**| html5-qrcode & qrcode.react | Scan kamera langsung di resepsionis tanpa perangkat scanner fisik |

---

## 🚀 Fitur Unggulan Sistem

### 1. Modul Pasien Mandiri (Mobile & Web PWA)
- **Booking Online**: Pemilihan poliklinik tujuan, dokter yang bertugas, tanggal kunjungan, serta formulir data pasien (NIK, nama, HP, keluhan).
- **E-Tiket QR Digital**: Nomor tiket terformat rapi (cth: `A-001`), kode booking unik (`MED-YYYYMMDD-XXXX`), dan barcode QR interaktif.
- **Dynamic ETA Countdown**: Estimasi jam panggilan, sisa menit tunggu secara dinamis yang terus diperbarui seiring berlangsungnya pemeriksaan dokter lain, serta info nomor antrean yang sedang diperiksa di ruang dokter.
- **Fitur Cetak Mandiri**: Tombol cetak tiket siap pakai yang disesuaikan dengan format kertas thermal printer.

### 2. Panel Kendali Dokter (Ruang Pemeriksaan)
- **Tombol Kontrol Alur Antrean**:
  - `Panggil`: Memanggil pasien berikutnya, mengubah status ke `CALLING`, mengirim sinyal panggilan ke TV dan HP pasien.
  - `Panggil Ulang` (Recall): Memutar ulang lonceng ding-dong dan panggilan suara di layar TV ruang tunggu.
  - `Mulai Konsultasi`: Menandai pasien telah masuk ruangan (`IN_CONSULTATION`) dan memulai timer pemeriksaan.
  - `Selesai`: Menyimpan catatan medis / resep obat singkat pasien (`COMPLETED`), mencatat durasi aktual, dan menghitung ulang ETA pasien berikutnya.
  - `Lewati`: Menandai pasien yang tidak hadir setelah panggilan berulang (`SKIPPED`).
- **Pengaturan Jadwal & Kuota**: Konfigurasi batas kuota harian, target durasi per pasien (menit), dan jam praktik.

### 3. Panel Admin & Resepsionis
- **Pemindai QR Code Check-in**: Kamera live pemindai tiket pasien yang langsung memvalidasi kedatangan pasien dan mengubah status tiket menjadi `CHECKED_IN`.
- **Pendaftaran Pasien Walk-in**: Pendaftaran pasien langsung di loket depan yang otomatis berstatus *checked-in* dan langsung mencetak struk tiket antrean.
- **Dasbor Monitoring Live**: Ringkasan metrik statistik hari ini (Total Pasien, Menunggu Check-in, Sedang Menunggu di Ruang Tunggu, Sedang Konsultasi, Selesai) serta per-poliklinik kartu monitoring.

### 4. Modul Rekam Medis & Riwayat Pasien (Patient History)
- **Portal Pasien Mandiri**: Pasien dapat mencari riwayat medis dan kunjungan masa lalunya menggunakan 16 digit NIK KTP.
- **Linimasa Pemeriksaan**: Menampilkan urutan tanggal kunjungan, poliklinik tujuan, dokter pemeriksa, keluhan awal, serta **catatan diagnosis & resep obat**.
- **Panel Dokter Terintegrasi**: Dokter dapat melihat riwayat medis lengkap pasien yang sedang aktif di ruang pemeriksaan hanya dengan satu klik tombol "Riwayat Medis".
- **Database & Pencarian Staf**: Resepsionis dan staf administrasi dapat mencari data riwayat pasien berdasarkan nama, NIK, atau nomor HP.
- **Cetak Resume Medis**: Opsi cetak ringkasan riwayat pemeriksaan pasien untuk keperluan rujukan atau dokumentasi pribadi.

### 5. Smart TV Display (Papan Antrean Ruang Tunggu)
- **Resolusi 1080p / 4K Responsif**: Tampilan tema gelap medis elegan berlatar belakang kontras tinggi.
- **Hero Calling Card**: Kartu panggilan nomor antrean raksasa yang menyala dengan animasi pulsa saat pasien dipanggil.
- **Audio TTS Otomatis**: Memutar nada lonceng ding-dong (*two-tone chime oscillator*) dilanjutkan suara pelafalan Bahasa Indonesia:
  > *"Nomor antrean A-001. Silakan menuju Poli Umum, Ruang 101."*
- **Multi-Counter Grid**: Menampilkan status antrean aktif seluruh poliklinik secara simultan.
- **Teks Berjalan (Marquee)**: Pengumuman informasi klinik yang dapat diperbarui secara terpusat.

---

## 🛠️ Panduan Instalasi & Menjalankan Proyek

### Prasyarat
- **Node.js** v18.0.0 atau lebih baru.
- **PostgreSQL** database aktif (atau container Docker PostgreSQL).

### Langkah 1: Clone / Ekstrak Proyek
Buka direktori proyek:
```bash
cd mediq
```

### Langkah 2: Konfigurasi Variabel Lingkungan (.env)
Salin berkas `.env.example` ke `server/.env`:
```bash
cp server/.env.example server/.env
```
Sesuaikan konfigurasi URL database PostgreSQL pada berkas `server/.env`:
```env
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/mediq_db?schema=public"
JWT_SECRET="mediq_super_secret_jwt_key_2026_clinic_secure"
```

### Langkah 3: Install Dependensi & Sinkronisasi Database
Jalankan perintah berikut di root proyek:
```bash
# 1. Install seluruh dependensi backend dan frontend
npm run install:all

# 2. Sinkronkan skema Prisma ORM ke database PostgreSQL Anda
npm run db:push

# 3. Masukkan data awal (seed) poliklinik, dokter, & antrean contoh
npm run db:seed
```

### Langkah 4: Menjalankan Server & Client
Buka dua terminal terpisah:

**Terminal 1 (Backend Server di port 5000):**
```bash
npm run server
```

**Terminal 2 (Frontend Client di port 5173):**
```bash
npm run client
```

Aplikasi siap diakses melalui browser:
- **Portal Utama**: [http://localhost:5173](http://localhost:5173)
- **Booking Pasien**: [http://localhost:5173/patient/booking](http://localhost:5173/patient/booking)
- **Layar Smart TV**: [http://localhost:5173/display](http://localhost:5173/display)
- **Login Staff / Dokter**: [http://localhost:5173/login](http://localhost:5173/login)

---

## 🔑 Kredensial Akun Default (Demo Seed Data)

| Peran (Role) | Email | Kata Sandi | Keterangan |
| :--- | :--- | :--- | :--- |
| **Dokter 1** | `dokter.andi@mediq.com` | `password123` | Dokter Umum (Poli Umum, Ruang 101) |
| **Dokter 2** | `dokter.sarah@mediq.com` | `password123` | Dokter Gigi (Poli Gigi, Ruang 102) |
| **Resepsionis**| `resepsionis@mediq.com` | `password123` | Front-desk check-in scanner & walk-in |
| **Administrator** | `admin@mediq.com` | `password123` | Akses penuh seluruh pengaturan klinik |

---

## 📡 Daftar Endpoint API & WebSocket Event

### REST API Endpoints
- `POST /api/auth/login` : Autentikasi staf & dokter (mengembalikan JWT Bearer Token)
- `GET /api/auth/me` : Informasi profil pengguna aktif
- `POST /api/patients/book` : Pendaftaran booking mandiri pasien (mengembalikan e-tiket & dynamic ETA)
- `GET /api/patients/ticket/:bookingCode` : Data detail e-tiket pasien berdasarkan kode booking
- `GET /api/patients/history/:nik` : Riwayat berobat & rekam medis pasien berdasarkan 16 digit NIK
- `GET /api/patients/details/:id` : Detail riwayat pasien berdasarkan ID pasien (untuk dokter)
- `GET /api/patients/search?q=...` : Pencarian pasien berdasarkan Nama, NIK, atau Nomor HP
- `GET /api/queues/display` : Payload status seluruh loket untuk Smart TV display
- `GET /api/queues/track/:code` : Lacak tiket berdasarkan nomor antrean atau kode booking
- `POST /api/queues/check-in` : Konfirmasi kedatangan pasien (pemindai QR Code)
- `POST /api/queues/walk-in` : Registrasi pasien walk-in langsung di tempat
- `POST /api/queues/:queueId/call` : Dokter memanggil nomor antrean berikutnya
- `POST /api/queues/:queueId/recall` : Dokter memanggil ulang nomor antrean aktif
- `POST /api/queues/:queueId/start` : Dokter memulai konsultasi
- `POST /api/queues/:queueId/finish` : Dokter menyelesaikan konsultasi & menyimpan diagnosis
- `POST /api/queues/:queueId/skip` : Dokter melewati pasien yang tidak hadir

### WebSocket Real-Time Events (Socket.io)
- `join:tv` : TV Display mendaftar ke kanal siaran publik
- `join:doctor` : Dokter terhubung ke saluran spesifik ruang praktiknya
- `join:patient` : Pasien memantau pembaruan nomor tiketnya secara *live*
- `queue:called` : Dipancarkan ke TV & Pasien saat nomor tiket dipanggil (memicu Web Speech API)
- `queue:status_changed` : Dipancarkan saat terjadi perubahan status antrean apa pun
- `tv:refresh` : Menginstruksikan layar TV memperbarui ringkasan antrean

---

## 📦 Mengompres Kode Sumber ke Zip

Untuk mengompres seluruh kode sumber aplikasi menjadi `mediq-app.zip` (tanpa menyertakan `node_modules`), jalankan skrip bash:

```bash
chmod +x package_project.sh
./package_project.sh
```

Atau melalui perintah npm root:
```bash
npm run package
```

File output `mediq-app.zip` akan siap didistribusikan langsung tanpa file sampah atau dependensi berat.

